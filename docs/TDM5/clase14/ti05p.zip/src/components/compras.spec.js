// /* global describe, it, expect */

// import { shallowMount } from "@vue/test-utils";
// import Compras from "@/components/Compras";

// console.log({ Compras });

// describe("Compras", () => {
//   const wrapper = shallowMount(Compras);
//   it("renders the correct markup", () => {
//     expect(wrapper.html()).toContain("Listado");
//   });
// });
